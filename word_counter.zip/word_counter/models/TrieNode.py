class TrieNode:
    def __init__(self):
        self.is_word = False
        self.children = {}
